import subprocess, pathlib, json, time, hashlib
OUT=pathlib.Path(__file__).resolve().parent
BASE=pathlib.Path('/home/linhao/Toolchain/development/llvm_autofdo_bolt_agent')
SDB=['sdb','-s','192.168.108.26:26101']
def run(name,args,timeout=30):
    start=time.time()
    p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
    (OUT/(name+'.stdout')).write_bytes(p.stdout)
    (OUT/(name+'.stderr')).write_bytes(p.stderr)
    (OUT/(name+'.json')).write_text(json.dumps(dict(argv=args,start=start,end=time.time(),returncode=p.returncode),indent=2)+'\n')
    if p.returncode: raise RuntimeError(name)
    return p.stdout.replace(b'\r\n',b'\n')
def shell(name,cmd,timeout=30): return run(name,SDB+['shell',cmd],timeout)
results={}
try:
    assert shell('uid-before','id -u').strip()==b'5001'
    run('root-on',SDB+['root','on'])
    assert shell('uid-root','id -u').strip()==b'0'
    cmd='''set -eu
test "$(tr -d '\\000' </proc/device-tree/serial-number)" = 100000004694d889
test "$(uname -m)" = armv7l
test -e /proc/device-tree/chosen/u-boot,version
mkdir -p /opt/afdo_agent/k1f-1/boot-ro
! findmnt -rn -S /dev/mmcblk0p1
mount -o ro /dev/mmcblk0p1 /opt/afdo_agent/k1f-1/boot-ro
trap 'umount /opt/afdo_agent/k1f-1/boot-ro' EXIT
findmnt -rn /opt/afdo_agent/k1f-1/boot-ro
cd /opt/afdo_agent/k1f-1/boot-ro
find . -type f -print0 | sort -z | xargs -0 sha256sum
df -B1 .
echo PREFLIGHT_BOOT_OK
'''
    data=shell('boot-ro',cmd,120).decode()
    assert 'PREFLIGHT_BOOT_OK' in data
    def manifest(text):
        return {s[66:]:s[:64] for s in text.splitlines() if len(s)>66 and s[64:66]=='  ' and all(c in '0123456789abcdef' for c in s[:64])}
    expected=manifest((BASE/'temp/kernel-afdo-k1/k1d-c-extra/write-receipts/boot-post.sha256').read_text())
    actual=manifest(data)
    results['boot']={'expected_count':len(expected),'actual_count':len(actual),'match':actual==expected,'differences':[k for k in expected.keys()|actual.keys() if expected.get(k)!=actual.get(k)]}
    data=shell('modules-ro','set -eu; findmnt -rn /usr/lib/modules; cd /lib/modules/6.12.80-arm-rpi4-v7l-kbase; find . -type f -print0 | sort -z | xargs -0 sha256sum; echo PREFLIGHT_MODULES_OK',90).decode()
    assert 'PREFLIGHT_MODULES_OK' in data
    expected=manifest((BASE/'temp/kernel-afdo-k1/k1d-c-extra/kbase-modules.sha256').read_text())
    actual=manifest(data)
    results['modules']={'expected_count':len(expected),'actual_count':len(actual),'match':actual==expected,'differences':[k for k in expected.keys()|actual.keys() if expected.get(k)!=actual.get(k)]}
    assert all(x['match'] for x in results.values()),results
    results['status']='passed'
except Exception as e:
    results.update(status='STOP',error=repr(e))
finally:
    run('root-off',SDB+['root','off'])
    assert shell('uid-after','id -u; findmnt -rn -S /dev/mmcblk0p1 || true').strip()==b'5001'
    (OUT/'board-preflight.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
