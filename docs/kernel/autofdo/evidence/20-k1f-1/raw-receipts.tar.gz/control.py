import pathlib, subprocess, os, json, time, socket, sys, hashlib
OUT=pathlib.Path(__file__).resolve().parent
REMOTE='/opt/afdo_agent/k1f-1'
DEV='192.168.108.26:26101'
SDB=['sdb','-s',DEV]
IDS={'kbase':'96766cfcbff8c33d83ca38152ad02f6a02dd44d4','kbase-s':'a78e6ca8956db526ba91d5856369fc1a7f15b5fd','plat':'395733b9c917cb98309b39cc3ec379c03ac36b3f'}
class Stop(Exception):pass
class RecoveryRequired(Stop):pass
def save(path,obj): path.write_text(json.dumps(obj,indent=2)+'\n')
def run(d,name,args,timeout=30,env=None):
    d.mkdir(parents=True,exist_ok=True)
    assert not (d/(name+'.stdout')).exists(),(d,name)
    t=time.time()
    try:
        p=subprocess.run([str(a) for a in args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,env=env)
        raw,err,rc=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:raw,err,rc=e.stdout or b'',e.stderr or b'',124
    (d/(name+'.stdout')).write_bytes(raw);(d/(name+'.stderr')).write_bytes(err)
    save(d/(name+'.json'),dict(argv=[str(a) for a in args],start=t,end=time.time(),returncode=rc))
    return rc,raw.decode(errors='replace').replace('\r','')
def shell(d,name,cmd,timeout=30):return run(d,name,SDB+['shell',cmd],timeout)
def checked(d,name,cmd,marker,timeout=30):
    rc,s=shell(d,name,cmd,timeout)
    if rc or marker not in s.splitlines():raise Stop(f'{name}: rc={rc}, missing marker={marker}')
    return s
def root(d,on):
    label='on' if on else 'off'
    rc,s=run(d,'root-'+label,SDB+['root',label])
    rc,s=shell(d,'uid-'+label,'id -u')
    if rc or s.strip()!=('0' if on else '5001'):raise Stop('UID '+label+' failed')
def write(mode,label):
    d=OUT/'writes'/label
    root(d,True)
    try:
        checked(d,'write',f'bash {REMOTE}/payload/boot-write.sh {mode} {label}','BOOT_WRITE_OK',120)
        rc,_=run(d,'pull',SDB+['pull',f'{REMOTE}/writes/{label}',str(d/'receipts')],120)
        if rc:raise Stop('write receipt pull failed')
    finally:root(d,False)
def reboot(d,variant):
    d.mkdir(parents=True,exist_ok=True)
    rc,old=shell(d,'previous-boot','cat /proc/sys/kernel/random/boot_id')
    if rc:raise Stop('no previous boot id')
    old=old.strip();root(d,True)
    (d/'driver.jsonl').write_text(json.dumps(dict(event='reboot_issued',previous=old))+'\n')
    t=time.monotonic();deadline=t+300;epoch=time.time()
    rec=dict(previous=old,variant=variant,start=epoch,disconnects=0,connects=0,server_restarts=0,tcp_after_down=None,connect_after_down=None,first_command=None)
    shell(d,'reboot','systemctl --no-block reboot'+(' "0 tryboot"' if variant!='plat' else ''),8)
    run(d,'disconnect',['sdb','disconnect',DEV],5);rec['disconnects']+=1
    down=False;last_disconnect=0;i=0
    while time.monotonic()<deadline:
        i+=1;elapsed=time.monotonic()-t
        try:
            with socket.create_connection(('192.168.108.26',26101),timeout=min(1,max(.05,deadline-time.monotonic()))):pass
            tcp=True
        except OSError:tcp=False;down=True
        with (d/'tcp.jsonl').open('a') as f:f.write(json.dumps(dict(elapsed=time.monotonic()-t,reachable=tcp,seen_down=down))+'\n')
        run(d,f'{i:03d}-ss',['ss','-tnp','dst',DEV],min(2,max(.05,deadline-time.monotonic())))
        run(d,f'{i:03d}-devices',['sdb','devices'],min(3,max(.05,deadline-time.monotonic())))
        if tcp and elapsed>=10:
            if down and rec['tcp_after_down'] is None:rec['tcp_after_down']=time.monotonic()-t
            rc,s=run(d,f'{i:03d}-connect',['sdb','connect',DEV],min(5,max(.05,deadline-time.monotonic())));rec['connects']+=1
            if down and rc==0 and 'connected to' in s and rec['connect_after_down'] is None:rec['connect_after_down']=time.monotonic()-t
            rc,s=shell(d,f'{i:03d}-identity',"cat /proc/sys/kernel/random/boot_id; uname -m; tr -d '\\000' </proc/device-tree/serial-number; echo",min(5,max(.05,deadline-time.monotonic())))
            lines=s.splitlines()
            if rc==0 and len(lines)>=3 and lines[0]!=old:
                if lines[1]!='armv7l' or lines[2]!='100000004694d889':raise Stop('reboot identity failed')
                rec.update(first_command=time.monotonic()-t,boot_id=lines[0],status='connected')
                save(d/'reboot-result.json',rec);return rec
            if elapsed-last_disconnect>=30:
                run(d,f'{i:03d}-disconnect',['sdb','disconnect',DEV],min(5,max(.05,deadline-time.monotonic())));rec['disconnects']+=1;last_disconnect=elapsed
        save(d/'reboot-progress.json',rec|dict(elapsed=time.monotonic()-t))
        time.sleep(min(5,max(0,deadline-time.monotonic())))
    rec.update(status='RECOVERY_REQUIRED',elapsed=time.monotonic()-t)
    save(d/'reboot-result.json',rec)
    raise RecoveryRequired('300 second reboot deadline: '+d.name)
def snapshot(d,variant,remote):
    mode='return' if variant=='plat' else 'direct'
    root(d/'snapshot',True)
    try:
        checked(d/'snapshot','collect',f'mkdir -p {remote}; bash {REMOTE}/payload/accept-snapshot.sh {mode} {remote}','SNAPSHOT_OK',90)
        rc,_=run(d/'snapshot','pull',SDB+['pull',f'{remote}/{mode}',str(d/mode)],120)
        if rc:raise Stop('snapshot pull failed')
        if variant=='plat':
            # The archived evaluator expects the pre-return direct boot id here.
            (d/'direct').mkdir(exist_ok=True)
            (d/'direct/boot-id').write_text(json.loads((d/'reboot-result.json').read_text())['previous']+'\n')
        env=dict(os.environ,K1E_SESSION=str(d),EXPECTED_BUILD_ID=IDS[variant],PYTHONDONTWRITEBYTECODE='1')
        rc,_=run(d/'snapshot','evaluate',[sys.executable,OUT/'evaluate-boot.py',mode],120,env)
        if rc:raise Stop('boot acceptance failed: '+d.name)
    finally:root(d/'snapshot',False)
def boot(label,variant,measure=False):
    d=OUT/'boots'/label
    if d.exists():raise Stop('refusing to overwrite boot '+label)
    if variant!='plat':write(variant,label)
    reboot(d,variant)
    remote=f'{REMOTE}/boots/{label}'
    snapshot(d,variant,remote)
    save(d/'status.json',dict(status='identity_passed',variant=variant,measure=measure))
    if not measure:return d
    root(d/'measurement',True)
    try:
        checked(d/'measurement','quiet',f'bash {REMOTE}/payload/quiet.sh {remote}','QUIET_OK',620)
        checked(d/'measurement','measure',f'bash {REMOTE}/payload/measure.sh {remote}/measure','MEASURE_COMPLETE',18000)
        rc,_=run(d/'measurement','pull',SDB+['pull',remote,str(d/'board')],180)
        if rc:raise Stop('measurement receipt pull failed')
        if (d/'board/measure/END').read_text().strip()!='measurement=0 cleanup=0':raise Stop('measurement cleanup failed')
        save(d/'status.json',dict(status='complete',variant=variant,measure=True))
    finally:root(d/'measurement',False)
    return d
def deploy():
    rows=json.loads((OUT/'sdb-diagnostic-summary.json').read_text())
    if len(rows)!=6 or any(r['status']!='passed' for r in rows):raise Stop('six reboot gate not passed')
    d=OUT/'deploy';root(d,True)
    try:
        rc,_=run(d,'push-payload',SDB+['push',str(OUT/'payload'),REMOTE+'/payload'],180)
        if rc:raise Stop('payload push failed')
        checked(d,'verify-payload',f'cd {REMOTE}/payload; sha256sum -c payload.sha256 && echo PAYLOAD_VERIFIED','PAYLOAD_VERIFIED',90)
        checked(d,'verify-inputs',f'cd {REMOTE}/payload; sha256sum -c existing-inputs.sha256 && echo INPUTS_VERIFIED','INPUTS_VERIFIED',90)
    finally:root(d,False)
    write('deploy','deploy-kbase-s')
if __name__=='__main__':
    action=sys.argv[1]
    try:
        if action=='deploy':deploy()
        elif action=='boot':boot(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='measure')
        else:raise ValueError(action)
    except RecoveryRequired as e:
        save(OUT/'terminal.json',dict(status='RECOVERY_REQUIRED',error=str(e),time=time.time()));raise
    except Exception as e:
        save(OUT/'terminal.json',dict(status='STOP',error=repr(e),time=time.time()));raise
