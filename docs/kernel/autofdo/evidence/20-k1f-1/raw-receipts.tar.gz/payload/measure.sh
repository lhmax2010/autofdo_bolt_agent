#!/bin/bash
set -euo pipefail
umask 077
export LC_ALL=C LD_LIBRARY_PATH=/opt/afdo_agent/lib
base=/opt/afdo_agent/k1f-1/payload
dir=$1
[[ "$dir" == /opt/afdo_agent/k1f-1/boots/*/measure ]]
perf=/opt/afdo_agent/tools/perf
[[ $(id -u) == 0 ]]
[[ $(tr -d '\000' </proc/device-tree/serial-number) == 100000004694d889 ]]
[[ -s "${dir%/measure}/QUIET_OK" ]]
mkdir "$dir"
cd "$dir"
export TMPDIR="$dir" PERF_BUILDID_DIR="$dir/buildid-cache"
export GST_REGISTRY="$dir/gstreamer-registry.bin" GST_REGISTRY_UPDATE=no
export XDG_CACHE_HOME="$dir/cache" XDG_CONFIG_HOME="$dir/config" XDG_STATE_HOME="$dir/state"
mkdir "$dir/ram" "$dir/exec"
uptime_s() { local s; read -r s _ < /proc/uptime; printf '%s\n' "$s"; }
sampler=''
worker=''
governors=()
for f in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    [[ -r "$f" ]]
    governors+=("$f")
    printf '%s\t%s\n' "$f" "$(cat "$f")"
done > original-governors.tsv
cleanup() {
    local rc=$? saved f restore=0
    trap - EXIT
    set +e
    for p in "$worker" "$sampler"; do
        if [[ -n "$p" ]]; then kill -TERM "$p" 2>/dev/null; wait "$p"; fi
    done
    while read -r f saved; do
        printf '%s\n' "$saved" > "$f"
        got=$(cat "$f")
        [[ "$got" == "$saved" ]] || restore=1
        printf '%s\t%s\t%s\n' "$f" "$saved" "$got"
    done < original-governors.tsv > restored-governors.tsv
    cd /
    for m in "$dir/ram" "$dir/exec"; do
        if mountpoint -q "$m"; then umount "$m" || restore=1; fi
    done
    printf 'measurement=%s cleanup=%s\n' "$rc" "$restore" > "$dir/END"
    ((restore==0)) || exit 70
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
mount -t tmpfs -o size=96M,nosuid,nodev,noexec tmpfs "$dir/ram"
mount -t tmpfs -o size=64M,nosuid,nodev,exec tmpfs "$dir/exec"
mkdir "$dir/exec/BASE"
tar xf "$base/BASE.tar" -C "$dir/exec/BASE"

cat /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq > fixed-khz
{
 for f in /sys/devices/system/cpu/cpufreq/policy*/{scaling_cur_freq,cpuinfo_cur_freq}; do
    [[ ! -r "$f" ]] || printf 'frequency\t%s\n' "$f"
 done
 for f in /sys/class/thermal/thermal_zone*/temp /sys/class/hwmon/hwmon*/temp*_input; do
    [[ ! -r "$f" ]] || printf 'temperature\t%s\n' "$f"
 done
 for f in /sys/class/hwmon/hwmon*/in0_lcrit_alarm; do
    [[ ! -r "$f" ]] || printf 'voltage\t%s\n' "$f"
 done
} > capabilities.tsv
grep -q '^temperature' capabilities.tsv
temperature() {
    local value max=-100000 f sensor
    while read -r sensor f; do
        [[ "$sensor" == temperature ]] || continue
        read -r value < "$f" || return 2
        [[ "$value" =~ ^-?[0-9]+$ ]] || return 2
        if ((value>max)); then max=$value; fi
    done < capabilities.tsv
    printf '%s\n' "$max"
}
switch() {
    local before f after value
    for f in "${governors[@]}"; do
        read -r before < "$f"
        if [[ "$before" != "$1" ]]; then printf '%s\n' "$1" > "$f"; fi
        read -r after < "$f"
        [[ "$after" == "$1" ]]
        read -r value < "${f%/*}/scaling_cur_freq"
        printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$(uptime_s)" "$2" "$f" "$before" "$after" "$value" >> governor-switches.tsv
    done
}
cool() {
    local deadline=$1 path=$2 tmp f freq
    while :; do
        tmp=$(temperature)
        printf '%s\t%s\t' "$(uptime_s)" "$tmp" >> "$path/gate.tsv"
        for f in "${governors[@]}"; do
            read -r freq < "${f%/*}/scaling_cur_freq"
            printf '%s\t' "$freq" >> "$path/gate.tsv"
        done
        cat /proc/loadavg >> "$path/gate.tsv"
        if ((tmp<=60000)); then break; fi
        ((SECONDS<deadline)) || return 75
        switch powersave "${path##*/}/cool"
        sleep 10
    done
    switch performance "${path##*/}/stabilize"
    sleep 3
}
run_round() {
    local key=$1 bench=$2 count=$3 deadline now ready exit_code=0 temp attempt=0
    local path="$dir/$key" artifacts
    local -a command
    mkdir -p "$path"
    case "$bench" in
        mmfault) command=("/opt/afdo_agent/k1d-a-20261118/closeout-20261119/mmfault" 64 "$count");;
        forkexec) command=("/opt/afdo_agent/k1d-a-20261118/closeout-20261119/forkexec" "$count" "/opt/afdo_agent/k1d-a-20261118/closeout-20261119/empty");;
        pipe) command=("$perf" bench sched pipe -l 500000);;
        syscall) command=("$perf" bench syscall basic -l 20000000);;
        tmpfs) command=(bash "$base/workload.sh" "$dir" tmpfs);;
        tos) command=(bash "$base/timed.sh" test "$dir/exec/BASE" /opt/afdo_agent/inputs/tos_720p_h264_60s.mp4 "$dir/tos-result");;

    esac
    printf '%q ' taskset -c 3 "${command[@]}" > "$path/argv"
    printf '\n' >> "$path/argv"
    printf '%s %s\n' "$(uptime_s)" "$key" > progress
    deadline=$((SECONDS+600))
    while :; do
        if ! cool "$deadline" "$path"; then printf '75\n' > "$path/exit"; return 75; fi
        ((++attempt))
        artifacts="$path/attempt-$attempt"
        mkdir "$artifacts"
        taskset -c 0 bash "$base/telemetry.sh" "$artifacts/telemetry.tsv" "$dir/capabilities.tsv" "$artifacts/ready" "$artifacts/request" "$artifacts/done" & sampler=$!
        until [[ -s "$artifacts/ready" ]]; do kill -0 "$sampler"; sleep .1; done
        read -r ready < "$artifacts/ready"
        until awk -v first="$ready" '{exit !($1 >= first+1.05)}' /proc/uptime; do kill -0 "$sampler"; sleep .1; done
        temp=$(temperature)
        printf '%s\n' "$temp" > "$artifacts/prestart-mC"
        if ((temp<=60000)); then break; fi
        kill -TERM "$sampler"; wait "$sampler"; sampler=''
        printf 'performance_start_gate\n' > "$artifacts/rejected"
        if ((SECONDS>=deadline)); then printf '75\n' > "$path/exit"; return 75; fi
        switch powersave "${path##*/}/postcheck-cool"
        sleep 10
    done
    printf '%s\n' "${artifacts##*/}" > "$path/accepted"
    uptime_s > "$artifacts/start.monotonic"
    WF_WALL_FILE="$path/wall" bash "$base/watchdog.sh" 90 "$perf" stat -x, -e cycles:k,cycles:u,task-clock,minor-faults -o "$path/stat.csv" -- taskset -c 3 "${command[@]}" > "$path/workload.txt" 2>&1 & worker=$!
    wait "$worker" || exit_code=$?
    worker=''
    now=$(uptime_s)
    printf '%s\n' "$now" > "$artifacts/end.monotonic"
    awk -v now="$now" 'BEGIN {printf "%.2f\n",now+1}' > "$artifacts/request.tmp"
    mv "$artifacts/request.tmp" "$artifacts/request"
    wait "$sampler"; sampler=''
    printf '%s\n' "$exit_code" > "$path/exit"
    ((exit_code==0)) || return "$exit_code"
    case "$bench" in
        tos) grep -q 'Got EOS' "$path/workload.txt" ;;
        tmpfs) grep -q TMPFS_OK "$path/workload.txt" ;;
        mmfault|forkexec) grep -q '^elapsed_ns=' "$path/workload.txt" ;;
    esac

    printf '%s %s done\n' "$(uptime_s)" "$key" > progress
}
for kind in pipe mmfault tmpfs syscall forkexec tos; do
    case "$kind" in mmfault) count=59;; forkexec) count=12774;; *) count=0;; esac
    run_round "$kind/warm-01" "$kind" "$count"
    for i in 1 2 3; do run_round "$kind/time-0$i" "$kind" "$count"; done
done
dmesg > "$dir/dmesg.after"
cat /proc/modules > "$dir/modules.after"
echo MEASURE_COMPLETE
