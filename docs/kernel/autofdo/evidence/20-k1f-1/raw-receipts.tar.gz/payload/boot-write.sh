#!/bin/bash
set -euo pipefail
export LC_ALL=C
cmp() { [[ $(sha256sum "$1" | cut -d' ' -f1) == $(sha256sum "$2" | cut -d' ' -f1) ]]; }
base=/opt/afdo_agent/k1f-1
mode=$1
[[ "$mode" == deploy || "$mode" == kbase || "$mode" == kbase-s ]]
[[ $(id -u) == 0 ]]
[[ $(tr -d '\000' </proc/device-tree/serial-number) == 100000004694d889 ]]
[[ $(blkid -s UUID -o value /dev/mmcblk0p1) == 404C-7537 ]]
[[ $(findmnt -n -o SOURCE /) == /dev/mmcblk0p2 ]]
findmnt -n -o OPTIONS /usr/lib/modules | grep -Eq '(^|,)ro(,|$)'
! findmnt -rn -S /dev/mmcblk0p1
out="$base/writes/$2"
[[ ! -e "$out" ]]
mkdir -p "$out" "$base/boot-ro" "$base/helper-exec"
m="$base/boot-ro"; x="$base/helper-exec"
cleanup() {
 rc=$?; trap - EXIT; cd /
 if mountpoint -q "$m"; then umount "$m" || rc=73; fi
 if mountpoint -q "$x"; then umount "$x" || rc=74; fi
 printf 'WRITE_EXIT=%s\n' "$rc" | tee "$out/exit"
 exit "$rc"
}
trap cleanup EXIT
mount -t tmpfs -o size=1048576,mode=0700,nosuid,nodev,exec tmpfs "$x"
cp "$base/payload/boot-publish" "$x/boot-publish"
chmod 0700 "$x/boot-publish"
helper="$x/boot-publish"
printf '%s  %s\n' 98d6c65c1a2e2b4fea6d6c46af6dc63a337cd81c8ef0ebf126e1fc5102a80c21 "$helper" | sha256sum -c -
inventory() { (cd "$m"; find . -type f -exec sha256sum {} + | sort -k2); }
mount -t vfat -o ro,nosuid,nodev,noexec /dev/mmcblk0p1 "$m"
inventory > "$out/before.sha256"
if [[ "$mode" == deploy ]]; then
 cmp "$base/payload/expected-boot.sha256" "$out/before.sha256"
 [[ ! -e "$m/zImage-kbase-s" && ! -e "$m/zImage-kbase-s.tmp" ]]
 read -r block available < <(stat -f -c '%S %a' "$m")
 old=$(stat -c %s "$m/zImage-plat-direct"); new=$(stat -c %s "$base/payload/zImage-kbase-s")
 left=$((block*available+((old+block-1)/block)*block-((new+block-1)/block)*block))
 printf 'block=%s available=%s remove=%s add=%s projected=%s\n' "$block" "$((block*available))" "$old" "$new" "$left" | tee "$out/budget.txt"
 [[ "$left" -ge 524288 ]]
else
 [[ -e "$m/zImage-$mode" && ! -e "$m/tryboot.txt.tmp" ]]
 sed "s/^kernel=zImage-kbase$/kernel=zImage-$mode/" "$base/payload/tryboot-kbase.txt" > "$out/tryboot.txt"
 sed '/^kernel=/d' "$m/tryboot.txt" > "$out/nonkernel.before"
 sed '/^kernel=/d' "$base/payload/tryboot-kbase.txt" > "$out/nonkernel.expected"
 cmp "$out/nonkernel.before" "$out/nonkernel.expected"
 if cmp "$out/tryboot.txt" "$m/tryboot.txt"; then
  cp "$out/before.sha256" "$out/after.sha256"
  echo CONFIG_ALREADY_MATCHES
  echo BOOT_WRITE_OK
  exit 0
 fi
fi
umount "$m"
mount -t vfat -o rw,nosuid,nodev,noexec /dev/mmcblk0p1 "$m"
inventory > "$out/rw-before.sha256"
cmp "$out/before.sha256" "$out/rw-before.sha256"
if [[ "$mode" == deploy ]]; then
 rm -- "$m/zImage-plat-direct"
 "$helper" syncfs "$m"
 name=zImage-kbase-s; source="$base/payload/$name"
else
 name=tryboot.txt; source="$out/tryboot.txt"
fi
(set -o noclobber; cat "$source" > "$m/$name.tmp")
"$helper" fsync "$m/$name.tmp"
sha256sum "$source" "$m/$name.tmp" | tee "$out/pre-publish.sha256"
[[ $(sha256sum "$source" | cut -d' ' -f1) == $(sha256sum "$m/$name.tmp" | cut -d' ' -f1) ]]
if [[ "$mode" == deploy ]]; then "$helper" publish "$m/$name.tmp" "$m/$name"; else mv -T "$m/$name.tmp" "$m/$name"; fi
"$helper" syncfs "$m"
cmp "$source" "$m/$name"
sha256sum "$m/$name" > "$out/readback.sha256"
umount "$m"
mount -t vfat -o ro,nosuid,nodev,noexec /dev/mmcblk0p1 "$m"
inventory > "$out/after.sha256"
if [[ "$mode" == deploy ]]; then
 sed '/  .\/zImage-plat-direct$/d' "$out/before.sha256" > "$out/unchanged.before"
 sed '/  .\/zImage-kbase-s$/d' "$out/after.sha256" > "$out/unchanged.after"
else
 sed '/  .\/tryboot.txt$/d' "$out/before.sha256" > "$out/unchanged.before"
 sed '/  .\/tryboot.txt$/d' "$out/after.sha256" > "$out/unchanged.after"
fi
cmp "$out/unchanged.before" "$out/unchanged.after"
cmp "$source" "$m/$name"
read -r block available < <(stat -f -c '%S %a' "$m")
[[ "$((block*available))" -ge 524288 ]]
df -B1 "$m" > "$out/after.df"
umount "$m"
echo BOOT_WRITE_OK
