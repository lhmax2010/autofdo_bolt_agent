import pathlib, json, sys, math, statistics as st, re, hashlib
OUT=pathlib.Path(__file__).resolve().parent
REPO=OUT.parent.parent
sys.path.insert(0,str(REPO/'workflow'))
from afdo_wf import stats
KINDS=['pipe','mmfault','tmpfs','syscall','forkexec','tos']
def boot_result(d):
    root=d/'board';measure=root/'measure'
    ident=json.loads((d/'direct-summary.json').read_text())
    caps={k:[] for k in ['frequency','temperature','voltage']}
    for line in (measure/'capabilities.tsv').read_text().splitlines():
        k,p=line.split();caps[k].append(p)
    fixed=int((measure/'fixed-khz').read_text())
    result=dict(boot_id=ident['boot_id'],build_id=ident['build_id'],path=str(d.relative_to(OUT)),benchmarks={},memory={})
    for line in (root/'meminfo.quiet').read_text().splitlines():
        k,v,*_=line.split();result['memory'][k.rstrip(':')]=int(v)
    q=[l.split() for l in (root/'quiet-gate.tsv').read_text().splitlines()]
    result['quiet']=dict(seconds=float(q[-1][0])-float(q[0][0])+5,samples=len(q),max_busy_pct=max(float(x[1]) for x in q),last_six_pct=[float(x[1]) for x in q[-6:]])
    assert len(q)>=6 and all(float(x[1])<2.91 for x in q[-6:])
    assert (measure/'END').read_text().strip()=='measurement=0 cleanup=0'
    for row in (measure/'restored-governors.tsv').read_text().splitlines():
        _,a,b=row.split();assert a==b
    for kind in KINDS:
        rounds=[]
        for n in range(1,4):
            p=measure/kind/f'time-{n:02d}'
            assert (p/'exit').read_text().strip()=='0'
            wall=float((p/'wall').read_text().strip())
            workload=(p/'workload.txt').read_text()
            primary=(int(re.search(r'^elapsed_ns=(\d+)',workload,re.M)[1])/1e9) if kind in ['mmfault','forkexec'] else wall
            accepted=(p/'accepted').read_text().strip();a=p/accepted
            samples=stats.parse_telemetry_tsv((a/'telemetry.tsv').read_text())
            start=float((a/'start.monotonic').read_text());end=float((a/'end.monotonic').read_text())
            telemetry=stats.telemetry(samples,start,end,fixed,caps)
            assert int((a/'prestart-mC').read_text())<=60000
            counts={}
            for line in (p/'stat.csv').read_text().splitlines():
                f=line.split(',')
                if len(f)>2:
                    try:counts[f[2]]=float(f[0])
                    except ValueError:pass
            rounds.append(dict(number=n,time_seconds=primary,external_wall_seconds=wall,telemetry=telemetry,counts=counts,prestart_mC=int((a/'prestart-mC').read_text()),max_temp_C=max(v for sample in samples for v in sample['temperature'].values() if v is not None),min_frequency_khz=min(v for sample in samples for v in sample['frequency'].values() if v is not None),max_frequency_khz=max(v for sample in samples for v in sample['frequency'].values() if v is not None),receipt=str(p.relative_to(OUT))))
        result['benchmarks'][kind]=dict(geomean=math.exp(st.mean(math.log(r['time_seconds']) for r in rounds)),rounds=rounds,flag='telemetry_anomaly' if any(r['telemetry']['classification']=='telemetry_anomaly' for r in rounds) else 'telemetry_missing' if any(r['telemetry']['classification']=='telemetry_missing' for r in rounds) else 'clean')
    old=sorted(l.split()[0] for l in (d/'direct/modules').read_text().splitlines())
    new=sorted(l.split()[0] for l in (measure/'modules.after').read_text().splitlines());assert old==new
    signature=re.compile(r'\bOops\b|\bBUG:|\bWARN(?:ING)?:|kernel panic|Unable to handle kernel|Internal error:|unknown symbol|version magic|disagrees about version|invalid module format|module verification failed',re.I)
    lines=lambda p:{re.sub(r'^\[\s*\d+(?:\.\d+)?\]\s*','',l) for l in p.read_text().splitlines() if signature.search(l)}
    assert not lines(measure/'dmesg.after')-lines(d/'direct/dmesg')
    (d/'measurement-result.json').write_text(json.dumps(result,indent=2)+'\n')
    return result
def analyze(phase,blocks):
    result=dict(phase=phase,blocks=len(blocks),benchmarks={},memory={},stats_sha256=hashlib.sha256((REPO/'workflow/afdo_wf/stats.py').read_bytes()).hexdigest())
    for kind in KINDS:
        rows=[];boots=[]
        for i,(control,candidate) in enumerate(blocks,1):
            a=control['benchmarks'][kind];b=candidate['benchmarks'][kind];boots.extend([a,b])
            rows.append(dict(id=i,complete=True,control=a['geomean'],candidate=b['geomean'],control_flag=a['flag'],candidate_flag=b['flag']))
        analysis=stats.analyze(rows,len(blocks),20261120,.01,20000)
        logs=[math.log(r['candidate']/r['control']) for r in rows]
        within=st.mean(st.variance(math.log(r['time_seconds']) for r in b['rounds']) for b in boots)
        bootvar=st.variance(math.log(b['geomean']) for b in boots)
        raw_n=math.ceil((1.96*1.2533*st.stdev(logs)/(.01/2))**2)
        analysis.update(paired_log_ratios=logs,paired_log_variance=st.variance(logs),within_boot_log_variance=within,boot_mean_log_variance=bootvar,between_boot_log_variance=max(0,bootvar-within/3),raw_N=raw_n,N=min(40,max(10,raw_n)),absolute_effect_ge_half_percent=abs(analysis['primary']['estimate'])>=.005)
        result['benchmarks'][kind]=analysis
    for key in blocks[0][0]['memory']:
        result['memory'][key]=dict(unit='KiB',paired_differences=[b['memory'][key]-a['memory'][key] for a,b in blocks])
    result['formal_N']=max(result['benchmarks'][k]['N'] for k in ['pipe','mmfault'])
    result['aa_gate_passed']=all(r['primary']['bootstrap_CI95'][0]<=0<=r['primary']['bootstrap_CI95'][1] for k,r in result['benchmarks'].items() if k in ['pipe','mmfault'])
    (OUT/(phase+'-analysis.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result
