#!/bin/bash
set -euo pipefail
export LC_ALL=C
d=$2
[[ "$d" == /opt/afdo_agent/k1f-1/boots/* ]]
kind=$1
[[ "$kind" == direct || "$kind" == return ]]
[[ "$(id -u)" == 0 ]]
[[ "$(tr -d '\000' </proc/device-tree/serial-number)" == 100000004694d889 ]]
out="$d/$kind"
mkdir "$out" "$out/module-notes"
cat /proc/sys/kernel/random/boot_id > "$out/boot-id"
cat /proc/version > "$out/proc-version"
uname -a > "$out/uname"
uname -m > "$out/uname-machine"
uname -r > "$out/uname-release"
grep '^CPU architecture' /proc/cpuinfo > "$out/cpu.arch"
cat /proc/cmdline > "$out/cmdline"
cp /sys/kernel/notes "$out/kernel.notes"
cp /sys/firmware/fdt "$out/live.fdt"
cp -rL /proc/device-tree/chosen/bootloader "$out/bootloader"
for key in bootargs u-boot,version linux,initrd-start linux,initrd-end; do
    f="/proc/device-tree/chosen/$key"
    if [[ -f "$f" ]]; then cp "$f" "$out/$key"; fi
done
cat /proc/modules > "$out/modules"
while read -r mod _; do
    file=$(modinfo -F filename "$mod" || true)
    vermagic=$(modinfo -F vermagic "$mod" || true)
    printf '%s\t%s\t%s\n' "$mod" "$file" "$vermagic"
    note="/sys/module/$mod/notes/.note.gnu.build-id"
    if [[ -r "$note" ]]; then cp "$note" "$out/module-notes/$mod.note"; fi
done < "$out/modules" > "$out/loaded-module-paths.tsv"
findmnt -rn -o TARGET,SOURCE,FSTYPE,OPTIONS > "$out/mounts"
date -u +%FT%TZ > "$out/runtime-time"
dmesg > "$out/dmesg"
dmesg -l emerg,alert,crit,err,warn > "$out/dmesg-warn"
{
    for f in /sys/class/drm/*/status; do printf '%s %s\n' "$f" "$(cat "$f")"; done
    systemctl is-active display-manager.service || :
    pidof enlightenment || :
    /usr/sbin/ip -4 -o address show dev eth0
    /usr/sbin/ip route show
    systemctl show sdbd_tcp.socket -p ActiveState -p Listen
} > "$out/display-net"
{
    for f in /sys/class/thermal/thermal_zone*/temp /sys/class/hwmon/hwmon*/temp*_input; do
        if [[ -r "$f" ]]; then printf '%s %s\n' "$f" "$(cat "$f")"; fi
    done
} > "$out/temperature"
dlogutil -t 20 > "$out/dlog.txt" 2>&1 && echo DLOG_EXIT=0 >> "$out/dlog.txt" || echo "DLOG_EXIT=$?" >> "$out/dlog.txt"
dbus-send --system --print-reply --reply-timeout=5000 --dest=org.freedesktop.DBus /org/freedesktop/DBus org.freedesktop.DBus.ListNames > "$out/dbus.txt" 2>&1 && echo DBUS_EXIT=0 >> "$out/dbus.txt" || echo "DBUS_EXIT=$?" >> "$out/dbus.txt"
{
    ls -l /dev/log_main
    grep -i kdbus /proc/devices || :
    pgrep -a dbus-daemon || :
} > "$out/dlog-dbus-transport.txt"
echo SNAPSHOT_OK
