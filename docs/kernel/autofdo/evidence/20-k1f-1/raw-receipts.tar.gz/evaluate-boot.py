#!/usr/bin/env python3
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys

task = Path(__file__).resolve().parent
work = Path(os.environ["K1E_SESSION"]).resolve()
reference = Path('/home/linhao/Toolchain/development/llvm_autofdo_bolt_agent/temp/kernel-afdo-k1/k1d-a/tryboot-plat')
stage = Path('/home/linhao/Toolchain/development/llvm_autofdo_bolt_agent/temp/kernel-afdo-k1/k1d-c-extra/staging/lib/modules/6.12.80-arm-rpi4-v7l-kbase')
plat_id = "395733b9c917cb98309b39cc3ec379c03ac36b3f"
kbase_id = os.environ["EXPECTED_BUILD_ID"]
mode = sys.argv[1]
assert mode in {"direct", "return"}
actual = work / mode
prior = reference / ("direct" if mode == "direct" else "before")
prior_cpu_arch = prior / "cpu.arch" if mode == "direct" else reference / "approved-uboot-cpu.arch"


def content(path):
    return path.read_text(errors="replace").strip()


def note_id(path):
    if not path.exists():
        return None
    raw = path.read_bytes()
    offset = 0
    while len(raw) - offset >= 12:
        names, size, kind = struct.unpack_from("<III", raw, offset)
        start = offset + 12
        payload = start + ((names + 3) & ~3)
        if payload + size > len(raw):
            return None
        if kind == 3 and raw[start:start + names] == b"GNU\0":
            return raw[payload:payload + size].hex()
        offset = payload + ((size + 3) & ~3)
    return None


def log_lines(path):
    for line in path.read_text(errors="replace").splitlines():
        yield re.sub(r"^\[\s*\d+(?:\.\d+)?\]\s*", "", line)


def difference(old, new):
    return list((collections.Counter(new) - collections.Counter(old)).elements())


def boot_mounts(path):
    return sorted(tuple(line.split()) for line in path.read_text().splitlines()
                  if len(line.split()) >= 4 and line.split()[1].startswith(("/dev/mmcblk0", "/dev/dm-", "/dev/mapper/")))


def names(path):
    return sorted(line.split()[0] for line in path.read_text().splitlines() if line.split())


signature = re.compile(
    r"\bOops\b|\bBUG:|\bWARN(?:ING)?:|kernel panic|Unable to handle kernel|Internal error:"
    r"|unknown symbol|version magic|disagrees about version|invalid module format|module verification failed"
    r"|(?:module|modprobe).*(?:failed|error)|(?:failed|error).*\b(?:module|modprobe)\b",
    re.I,
)

def signature_lines(path):
    return sorted({re.sub(r"\b(CPU|PID): \d+", r"\1: N", line)
                   for line in log_lines(path) if signature.search(line)})


new_serious = sorted(set(signature_lines(actual / "dmesg")) - set(signature_lines(prior / "dmesg")))
mounts = boot_mounts(actual / "mounts")
modules = names(actual / "modules")
flags = actual / "bootloader/tryboot"
display = (actual / "display-net").read_text().splitlines()
direct_boot_id = work / "direct/boot-id"
previous_boot = next(json.loads(line)["previous"] for line in (work / "driver.jsonl").read_text().splitlines() if json.loads(line)["event"] == "reboot_issued") if mode == "direct" else content(direct_boot_id)
results = {
    "mode": mode,
    "boot_id": content(actual / "boot-id"),
    "old_boot_id": previous_boot,
    "build_id": note_id(actual / "kernel.notes"),
    "release": content(actual / "uname-release"),
    "tryboot": int.from_bytes(flags.read_bytes(), "big") if flags.exists() else None,
    "u_boot": (actual / "u-boot,version").exists(),
    "machine": content(actual / "uname-machine"),
    "cpu_arch_equal": (actual / "cpu.arch").read_bytes() == prior_cpu_arch.read_bytes(),
    "cmdline_equal": (actual / "cmdline").read_bytes() == (prior / "cmdline").read_bytes(),
    "fdt_sha256": hashlib.sha256((actual / "live.fdt").read_bytes()).hexdigest(),
    "mounts_equal": mounts == boot_mounts(prior / "mounts"),
    "rootfs_and_p6": any(row[:2] == ("/", "/dev/mmcblk0p2") for row in mounts) and
                   any(row[:3] == ("/usr/lib/modules", "/dev/mmcblk0p6", "ext4") and "ro" in row[3].split(",") for row in mounts),
    "modules": modules,
    "module_set_equal": len(modules) == 10 and modules == names(prior / "modules"),
    "new_oops_bug_warn_module_failure": new_serious,
    "display_net": any(line.endswith("-HDMI-A-1/status connected") for line in display)
                   and "active" in display and any(re.fullmatch(r"[0-9]+(?: [0-9]+)*", line) for line in display)
                   and any("inet 192.168.108.26/" in line for line in display) and "ActiveState=active" in display,
    "dlog": "DLOG_EXIT=0" in content(actual / "dlog.txt")
            and bool(re.search(r"^[VDIWEF]/", content(actual / "dlog.txt"), re.M))
            and "/dev/log_main" in content(actual / "dlog-dbus-transport.txt"),
    "dbus": "DBUS_EXIT=0" in content(actual / "dbus.txt")
            and "method return" in content(actual / "dbus.txt")
            and "sender=org.freedesktop.DBus" in content(actual / "dbus.txt")
            and bool(re.search(r'string "org\.tizen\.[^"]+"', content(actual / "dbus.txt"))),
    "temperature": content(actual / "temperature").splitlines(),
}
added = difference(log_lines(prior / "dmesg-warn"), log_lines(actual / "dmesg-warn"))
removed = difference(log_lines(actual / "dmesg-warn"), log_lines(prior / "dmesg-warn"))
(work / f"{mode}-dmesg-warning-delta.txt").write_text(
    "".join(f"+ {s}\n" for s in added) + "".join(f"- {s}\n" for s in removed)
)
problems = []
for field in ("cpu_arch_equal", "cmdline_equal", "rootfs_and_p6", "display_net"):
    if not results[field]:
        problems.append(field)
if results["boot_id"] == previous_boot or results["machine"] != "armv7l":
    problems.append("boot identity or architecture")
if mode == "direct":
    if (results["build_id"], results["release"], results["tryboot"], results["u_boot"]) != (
        kbase_id, stage.name, 1, False
    ):
        problems.append("K-BASE build-id, release or tryboot")
    driver = Path('/home/linhao/Toolchain/development/llvm_autofdo_bolt_agent/temp/kernel-afdo-k1/k1e/compare-fdt.sh')
    check = subprocess.run(["bash", driver, actual / "live.fdt"], check=False)
    results["normalized_fdt_equal"] = check.returncode == 0
    if not results["normalized_fdt_equal"]:
        problems.append("normalized FDT")
    for field in ("mounts_equal", "module_set_equal", "dlog", "dbus"):
        if not results[field]:
            problems.append(field)
    if new_serious:
        problems.append("new Oops/BUG/WARNING/module failure")
    recorded = []
    for line in (actual / "loaded-module-paths.tsv").read_text().splitlines():
        name, path, vermagic = line.split("\t")
        prefix = re.compile(r"^/(?:usr/)?lib/modules/" + re.escape(stage.name) + r"/")
        relative = prefix.sub("", path)
        has_path = relative != path and (stage / relative).is_file()
        runtime_id = note_id(actual / "module-notes" / (name + ".note"))
        staged_id = None
        if has_path:
            notes = subprocess.check_output(["readelf", "-n", stage / relative], text=True)
            match = re.search(r"Build ID: ([0-9a-f]+)", notes)
            staged_id = match[1] if match else None
        ok = has_path and vermagic.startswith(stage.name + " ") and runtime_id is not None and runtime_id == staged_id
        recorded.append({"module": name, "path": path, "vermagic": vermagic, "runtime_id": runtime_id,
                         "staged_id": staged_id, "verified": ok})
    results["loaded_module_identity"] = recorded
    if len(recorded) != 10 or not all(row["verified"] for row in recorded):
        problems.append("loaded module paths, vermagic or build ID")
else:
    if (results["build_id"], results["release"], results["tryboot"], results["u_boot"]) != (
        plat_id, "6.12.80-arm-rpi4-v7l", 0, True
    ):
        problems.append("original PLAT U-Boot identity")
results["problems"] = problems
result = json.dumps(results, indent=2) + "\n"
(work / f"{mode}-summary.json").write_text(result)
print(result)
sys.exit(bool(problems))
