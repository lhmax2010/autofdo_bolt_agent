import os, subprocess, socket, time, json, pathlib, sys
OUT=pathlib.Path(__file__).resolve().parent
DEV='192.168.108.26:26101'
SDB=['sdb','-s',DEV]
NOTE='146a4e2d870f3f65fdc6c6f9ca738e3cabcb83bbf4dc6f96bbcdd18c6776ab35'
CMD='1a132093c6e7220e981bd54c1a6a7bf780a19927c9787d3c9dcb7149eff106b4'
IDENT="id -u; uname -m; cat /proc/sys/kernel/random/boot_id; sha256sum /sys/kernel/notes /proc/cmdline; od -An -tx1 /proc/device-tree/chosen/bootloader/tryboot; cat /proc/device-tree/chosen/u-boot,version; echo; tr -d '\\000' </proc/device-tree/serial-number; echo"
def run(d,name,args,timeout=8,deadline=None):
    if deadline: timeout=min(timeout,max(.05,deadline-time.monotonic()))
    t=time.monotonic(); start=time.time()
    env=dict(os.environ,SDB_DEBUG='1',SDB_TRACE_PACKET='1')
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,env=env)
        raw,err,rc=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e: raw,err,rc=e.stdout or b'',e.stderr or b'',124
    (d/(name+'.stdout')).write_bytes(raw);(d/(name+'.stderr')).write_bytes(err)
    with (d/'commands.jsonl').open('a') as f:f.write(json.dumps(dict(name=name,argv=args,start_utc_epoch=start,duration=time.monotonic()-t,rc=rc))+'\n')
    return rc,raw.decode(errors='replace').replace('\r','')
def valid(s,old=None):
    lines=s.splitlines()
    return len(lines)>6 and lines[1]=='armv7l' and (old is None or lines[2]!=old) and NOTE in s and CMD in s and '00 00 00 00' in s and 'TIZEN.org' in s and '100000004694d889' in s
summary=[]
for n in range(1,7):
    d=OUT/f'plat-reboot-{n:02d}';d.mkdir(exist_ok=False)
    run(d,'devices-before',['sdb','devices'])
    run(d,'devices-l-before',['sdb','devices','-l'])
    run(d,'ss-before',['ss','-tnp','dst',DEV])
    rc,s=run(d,'identity-before',SDB+['shell',IDENT]);assert rc==0 and valid(s),s
    old=s.splitlines()[2]
    assert run(d,'root-on',SDB+['root','on'])[0]==0
    assert run(d,'uid-root',SDB+['shell','id -u'])[1].strip()=='0'
    t0=time.monotonic();deadline=t0+300
    rec=dict(number=n,old_boot_id=old,reboot_utc_epoch=time.time(),tcp_seconds=None,connect_seconds=None,command_seconds=None,disconnects=0,connects=0,server_restarts=0)
    run(d,'reboot',SDB+['shell','systemctl --no-block reboot'],deadline=deadline)
    run(d,'disconnect-immediate',['sdb','disconnect',DEV],deadline=deadline);rec['disconnects']+=1
    k=0;lastdisconnect=0
    while time.monotonic()<deadline:
        k+=1;elapsed=time.monotonic()-t0
        run(d,f'{k:03d}-ss',['ss','-tnp','dst',DEV],timeout=2,deadline=deadline)
        try:
            with socket.create_connection(('192.168.108.26',26101),timeout=min(1,max(.05,deadline-time.monotonic()))):pass
            tcp=True
            if elapsed>=5 and rec['tcp_seconds'] is None:rec['tcp_seconds']=time.monotonic()-t0
        except OSError:tcp=False
        run(d,f'{k:03d}-devices',['sdb','devices'],timeout=3,deadline=deadline)
        if tcp and elapsed>=10:
            rc,c=run(d,f'{k:03d}-connect',['sdb','connect',DEV],timeout=5,deadline=deadline);rec['connects']+=1
            if rc==0 and 'connected to' in c and rec['connect_seconds'] is None:rec['connect_seconds']=time.monotonic()-t0
            rc,s=run(d,f'{k:03d}-command',SDB+['shell',IDENT],timeout=5,deadline=deadline)
            if rc==0 and valid(s,old):
                rec.update(command_seconds=time.monotonic()-t0,new_boot_id=s.splitlines()[2],status='passed')
                break
            if rc==0 and len(s.splitlines())>2 and s.splitlines()[2]!=old and not valid(s,old):
                rec.update(status='STOP',reason='identity assertion failed',identity=s);break
            if elapsed-lastdisconnect>=30:
                run(d,f'{k:03d}-disconnect',['sdb','disconnect',DEV],timeout=5,deadline=deadline);rec['disconnects']+=1;lastdisconnect=elapsed
        (d/'progress.json').write_text(json.dumps(rec|dict(elapsed=time.monotonic()-t0,tcp=tcp),indent=2)+'\n')
        time.sleep(min(5,max(0,deadline-time.monotonic())))
    if 'status' not in rec:rec.update(status='RECOVERY_REQUIRED',reason='300 second reboot deadline exceeded')
    if rec['status']=='passed':
        run(d,'root-off',SDB+['root','off'])
        rc,s=run(d,'identity-after',SDB+['shell',IDENT])
        if rc!=0 or not valid(s,old) or s.splitlines()[0]!='5001':rec.update(status='STOP',reason='final identity or UID failed')
    run(d,'devices-after',['sdb','devices'])
    run(d,'ss-after',['ss','-tnp','dst',DEV])
    (d/'result.json').write_text(json.dumps(rec,indent=2)+'\n');summary.append(rec)
    (OUT/'sdb-diagnostic-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(rec),flush=True)
    if rec['status']!='passed':sys.exit(2)
