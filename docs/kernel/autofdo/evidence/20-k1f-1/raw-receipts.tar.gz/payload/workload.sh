#!/bin/bash
set -euo pipefail
suite=$1
kind=$2
export LD_LIBRARY_PATH=/opt/afdo_agent/lib
perf=/opt/afdo_agent/tools/perf
case "$kind" in
    pipe) exec "$perf" bench sched pipe -l 500000 ;;
    syscall) exec "$perf" bench syscall basic -l 20000000 ;;
    tmpfs)
        file="$suite/ram/payload"
        trap 'rm -f -- "$file"' EXIT
        for ((iteration=0; iteration<8; iteration++)); do
            dd if=/dev/zero of="$file" bs=1048576 count=64
            test "$(stat -c %s "$file")" -eq 67108864
            dd if="$file" of=/dev/null bs=1048576 count=64
            rm -- "$file"
        done
        echo TMPFS_OK
        ;;
    memory)
        awk '/^MemAvailable:/ { found=1; ok=($2 >= 1572864) } END { exit !(found && ok) }' /proc/meminfo
        exec "$suite/memory-worker"
        ;;
    tos)
        exec bash "$suite/timed.sh" test "$suite/BASE" /opt/afdo_agent/inputs/tos_720p_h264_60s.mp4 "$suite/tos-result"
        ;;
    *) exit 2 ;;
esac
